from setuptools import setup

setup(name='gb_proba',
      version='0.1',
      description='Gaussian and Binomial distributions',
      packages=['gb_proba'],
      author = 'Ben Chan',
      zip_safe=False)